---
layout: paper
type: paper
published: true
title: "Chemical inhibition of apicoplast biogenesis"
date: 2018
paperurl: https://searchworks.stanford.edu/view/12736277
---
Amberg-Johnson, K. Ph.D. Thesis, Stanford University (2018)
