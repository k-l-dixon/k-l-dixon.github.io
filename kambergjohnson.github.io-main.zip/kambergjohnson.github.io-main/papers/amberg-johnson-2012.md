---
layout: paper
type: paper
published: true
title: "Use of Molecular Tweezers to Study the Effect of Applied Force on σ54 Core-Binding Domain"
date: 2012
paperurl: resources/amberg-johnson-undergrad-honors-thesis.pdf
---
Katherine Amberg-Johnson (2012) Undergraduate Honors Thesis, UC Berkeley.
