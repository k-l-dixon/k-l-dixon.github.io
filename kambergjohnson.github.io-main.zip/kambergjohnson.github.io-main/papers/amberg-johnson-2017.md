---
layout: paper
type: paper
published: true
title: "Small molecule inhibition of apicomplexan FtsH1 disrupts plastid biogenesis in human pathogens"
date: 2017
paperurl: https://www.ncbi.nlm.nih.gov/pubmed/28826494
---
Katherine Amberg-Johnson, Sanjay B Hari, Suresh M Ganesan, Hernan A Lorenzi, Robert T Sauer, Jacquin C Niles, Ellen Yeh. (2017) eLife 2017;6:e29865
