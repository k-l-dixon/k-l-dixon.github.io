---
layout: paper
type: paper
published: true
title: "Host cell metabolism contributes to delayed-death kinetics of apicoplast inhibitors in Toxoplasma gondii"
date: 2019
paperurl: https://www.ncbi.nlm.nih.gov/pubmed/30455243
---
Amberg-Johnson, K., & Yeh, E. (2019). Antimicrob Agents Chemother. 2019 Jan 29; 63(2)
